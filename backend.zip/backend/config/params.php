<?php
return [
    'adminEmail' => 'admin@example.com',
    'bsVersion' => '5.x',
];
