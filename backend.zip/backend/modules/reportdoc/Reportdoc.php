<?php

namespace backend\modules\reportdoc;

/**
 * reportdoc module definition class
 */
class Reportdoc extends \yii\base\Module
{
    /**
     * {@inheritdoc}
     */
    public $controllerNamespace = 'backend\modules\reportdoc\controllers';

    /**
     * {@inheritdoc}
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
